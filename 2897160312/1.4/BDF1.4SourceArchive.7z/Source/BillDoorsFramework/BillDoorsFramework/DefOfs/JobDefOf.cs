﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Verse;

namespace BillDoorsFramework
{
    [DefOf]
    public static class JobDefOf
    {
        public static JobDef BDsBombDisarm;

        public static JobDef BDF_RearmTurretWithMagazine;
    }
}
