// BillDoorsFramework.DefModExtension_GraphicDataByTechLevel
using System.Collections.Generic;
using BillDoorsFramework;
using RimWorld;
using Verse;
namespace BillDoorsFramework
{

    public class DefModExtension_GraphicDataByTechLevel : DefModExtension
    {
        public List<GraphicDataAndTechLevelPair> graphicDatas;
    }
}
