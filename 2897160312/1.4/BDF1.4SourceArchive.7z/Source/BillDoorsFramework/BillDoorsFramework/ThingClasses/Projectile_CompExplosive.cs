﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using UnityEngine;
using Verse;

namespace BillDoorsFramework
{
    public class Projectile_CompExplosive : Bullet
    {
        protected override void Impact(Thing hitThing, bool blockedByShield = false)
        {
            if (hitThing != null)
            {
                this.Position = hitThing.TrueCenter().ToIntVec3();
            }
            var comps = this.GetComps<CompExplosiveExposed>();
            foreach (var comp in comps)
            {
                comp.DoDetonate(this.Map);
            }
            base.Impact(hitThing, blockedByShield);
        }
    }

    public class CompExplosiveExposed : CompExplosive
    {
        public void DoDetonate(Map map, bool ignoreUnspawned = false)
        {
            Detonate(map, ignoreUnspawned);
        }
    }
}
