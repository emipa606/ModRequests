﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using UnityEngine;
using Verse;

namespace BillDoorsFramework
{
    public class Projectile_ExplosiveReturnArcHeight : Projectile_Explosive
    {
        private static readonly Material shadowMaterial = MaterialPool.MatFrom("Things/Skyfaller/SkyfallerShadowCircle", ShaderDatabase.Transparent);
        Vector3 lastPos;
        private float ArcHeightFactor
        {
            get
            {
                float num = def.projectile.arcHeightFactor;
                float num2 = (destination - origin).MagnitudeHorizontalSquared();
                if (num * num > num2 * 0.2f * 0.2f)
                {
                    num = Mathf.Sqrt(num2) * 0.2f;
                }
                return num;
            }
        }
        Quaternion adjustedRot => lastPos == Vector3.zero ? ExactRotation : Quaternion.LookRotation((DrawPos - lastPos).Yto0());
        public override Vector3 DrawPos => ExactPosition + new Vector3(0f, 0f, 1f) * ArcHeightFactor * GenMath.InverseParabola(DistanceCoveredFraction);
        public override void Draw()
        {
            if (def.projectile.shadowSize > 0f)
            {
                DrawShadow(DrawPos);
            }
            Graphics.DrawMesh(MeshPool.GridPlane(def.graphicData.drawSize), DrawPos, adjustedRot, DrawMat, 0);
            Comps_PostDraw();
        }

        public override void Tick()
        {
            lastPos = DrawPos;
            base.Tick();
        }

        private void DrawShadow(Vector3 drawLoc)
        {
            if (!(shadowMaterial == null))
            {
                float num = def.projectile.shadowSize * Mathf.Lerp(1f, 0.6f, ArcHeightFactor * GenMath.InverseParabola(DistanceCoveredFraction));
                Vector3 s = new Vector3(num, 1f, num);
                Vector3 vector = new Vector3(0f, -0.01f, 0f);
                Matrix4x4 matrix = default(Matrix4x4);
                matrix.SetTRS(drawLoc + vector, Quaternion.identity, s);
                Graphics.DrawMesh(MeshPool.plane10, matrix, shadowMaterial, 0);
            }
        }
    }
}
