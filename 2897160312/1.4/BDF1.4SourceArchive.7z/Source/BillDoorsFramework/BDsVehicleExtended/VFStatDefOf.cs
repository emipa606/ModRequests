﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using RimWorld;
using Vehicles;
using Verse;

namespace BillDoorsFramework
{
    [DefOf]
    public static class VFStatDefOf
    {
        static VFStatDefOf()
        {
            DefOfHelper.EnsureInitializedInCtor(typeof(VehicleStatDefOf));
        }
        public static VehicleStatDef BDsVehiclePowerRecharge;

        public static VehicleStatDef BDsVehiclePowerCapacitor;

        public static VehicleStatDef BDsVehicleGeneratorFuelUseage;
    }
}
