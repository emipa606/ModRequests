Copies of all language files in one place so translators aren't rooting around 100's of folders

Drop by our discord if you want your translation added into the mod https://discord.gg/wsycYmryeX