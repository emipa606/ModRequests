﻿using RimWorld;
using Verse;

namespace Amrita
{
    // main

    public class HediffComp_ReverseAge : HediffComp
    {
        public HediffCompProperties_ReverseAge Props => (HediffCompProperties_ReverseAge)props;


        public int lastCheckedTick = 9;
        public int nowCheckedTick;
        public int TicksPerHour = GenDate.TicksPerHour;

        public override void CompPostMake()
        {
            lastCheckedTick = Find.TickManager.TicksGame;
        }

        public override void CompPostTick(ref float severityAdjustment)
        {
            nowCheckedTick = Find.TickManager.TicksGame;
            if (nowCheckedTick > lastCheckedTick + TicksPerHour)
            {
                Pawn.ageTracker.AgeBiologicalTicks -= (long)(TicksPerHour * (1f + Props.reversePerDay));
                lastCheckedTick = nowCheckedTick;
            }
        }
    }
    public class HediffCompProperties_ReverseAge : HediffCompProperties
    {
        public float reversePerDay = 1f;

        public HediffCompProperties_ReverseAge()
        {
            compClass = typeof(HediffComp_ReverseAge);
        }
    }

    // get HediffDef from XML node and remove corresponding Hediff from Pawn

    public class HediffCompProperties_ExpireHediff : HediffCompProperties
    {
        public HediffDef hediffToExpire;

        public HediffCompProperties_ExpireHediff()
        {
            compClass = typeof(HediffComp_ExpireHediff);
        }
    }

    public class HediffComp_ExpireHediff : HediffComp
    {
        public HediffCompProperties_ExpireHediff Props => (HediffCompProperties_ExpireHediff)props;

        public override void CompPostMake()
        {
            HediffDef hediffToExpire = Props.hediffToExpire;

            if (Pawn.health.hediffSet.HasHediff(hediffToExpire))
            {
                Pawn.health.RemoveHediff(Pawn.health.hediffSet.GetFirstHediffOfDef(hediffToExpire));
            }           
        }
    }
}